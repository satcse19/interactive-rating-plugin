<?php
function irp_rating_survey_shortcode() {
    ob_start();
    ?>
    <div class="irp-survey-container">
        <div class="irp-question-container">
            <!-- Questions will be loaded here via AJAX -->
        </div>
        <div class="irp-email-container" style="display:none;">
            <h3>Thank you for completing our survey!</h3>
            <p>Please enter your email to receive the results:</p>
            <input type="email" id="irp-user-email" placeholder="your@email.com">
            <button id="irp-submit-email" class="irp-button">Submit</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('interactive_rating_survey', 'irp_rating_survey_shortcode');

function irp_get_question_callback() {
    check_ajax_referer('irp_nonce', 'nonce');
    
    global $wpdb;
    $db = new IRP_Database();
    $questions = $db->get_questions();
    
    $session_id = isset($_COOKIE['irp_session_id']) ? $_COOKIE['irp_session_id'] : uniqid();
    setcookie('irp_session_id', $session_id, time() + 3600, '/');
    
    $question_index = isset($_POST['question_index']) ? intval($_POST['question_index']) : 0;
    
    if ($question_index >= count($questions)) {
        wp_send_json(array(
            'status' => 'complete',
            'message' => 'All questions completed'
        ));
    }
    
    $question = $questions[$question_index];
    
    ob_start();
    ?>
    <div class="irp-question" data-question-id="<?php echo $question->id; ?>" data-question-index="<?php echo $question_index; ?>">
        <h3><?php echo esc_html($question->question_text); ?></h3>
        <div class="irp-rating-scale">
            <span class="irp-min-label"><?php echo esc_html($question->min_label); ?></span>
            <div class="irp-rating-options">
                <?php for ($i = $question->min_value; $i <= $question->max_value; $i++): ?>
                    <div class="irp-rating-option" data-value="<?php echo $i; ?>">
                        <span class="irp-option-number"><?php echo $i; ?></span>
                    </div>
                <?php endfor; ?>
            </div>
            <span class="irp-max-label"><?php echo esc_html($question->max_label); ?></span>
        </div>
        <!-- Buttons will be added by JavaScript -->
    </div>
    <?php
    $html = ob_get_clean();
    
    wp_send_json(array(
        'status' => 'success',
        'html' => $html,
        'question_index' => $question_index,
        'total_questions' => count($questions),
        'session_id' => $session_id
    ));
}

function irp_save_response_callback() {
    check_ajax_referer('irp_nonce', 'nonce');
    
    $question_id = isset($_POST['question_id']) ? intval($_POST['question_id']) : 0;
    $rating_value = isset($_POST['rating_value']) ? intval($_POST['rating_value']) : 0;
    $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
    
    if (!$question_id || !$session_id) {
        wp_send_json_error('Missing required data');
    }
    
    $db = new IRP_Database();
    $result = $db->save_response($question_id, $rating_value, $session_id);
    
    if ($result) {
        wp_send_json_success('Response saved');
    } else {
        wp_send_json_error('Failed to save response');
    }
}

function irp_save_email_callback() {
    check_ajax_referer('irp_nonce', 'nonce');
    
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
    
    if (!is_email($email) || !$session_id) {
        wp_send_json_error('Invalid email or session ID');
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'irp_responses';
    $result = $wpdb->query($wpdb->prepare(
        "UPDATE $table_name SET user_email = %s WHERE session_id = %s",
        $email, $session_id
    ));
    
    if ($result !== false) {
        wp_send_json_success('Email saved successfully');
    } else {
        wp_send_json_error('Failed to save email');
    }
}