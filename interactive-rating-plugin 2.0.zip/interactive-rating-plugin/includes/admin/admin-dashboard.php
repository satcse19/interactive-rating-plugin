<?php
function irp_add_admin_menu() {
    add_menu_page(
        'Interactive Rating Plugin',
        'Rating Surveys',
        'manage_options',
        'interactive-rating-plugin',
        'irp_admin_dashboard_page',
        'dashicons-chart-bar',
        30
    );
}
add_action('admin_menu', 'irp_add_admin_menu');

function irp_admin_dashboard_page() {
    $db = new IRP_Database();
    $questions = $db->get_questions();
    $submissions = $db->get_grouped_submissions();
    ?>
    <div class="wrap irp-admin-container">
        <h1>Interactive Rating Plugin</h1>
        
        <div class="irp-tabs">
            <button class="irp-tab-button active" data-tab="questions">Questions</button>
            <button class="irp-tab-button" data-tab="submissions">Submissions</button>
            <button class="irp-tab-button" data-tab="add-question">Add New Question</button>
        </div>
        
        <div id="questions" class="irp-tab-content active">
            <h2>Survey Questions</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Question</th>
                        <th>Min Label</th>
                        <th>Max Label</th>
                        <th>Min Value</th>
                        <th>Max Value</th>
                        <th>Order</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($questions as $question): ?>
                    <tr>
                        <td><?php echo esc_html($question->question_text); ?></td>
                        <td><?php echo esc_html($question->min_label); ?></td>
                        <td><?php echo esc_html($question->max_label); ?></td>
                        <td><?php echo $question->min_value; ?></td>
                        <td><?php echo $question->max_value; ?></td>
                        <td><?php echo $question->display_order; ?></td>
                        <td>
                            <button class="button irp-edit-question" data-id="<?php echo $question->id; ?>">Edit</button>
                            <button class="button button-danger irp-delete-question" data-id="<?php echo $question->id; ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div id="submissions" class="irp-tab-content">
            <h2>Survey Submissions</h2>
            <div class="irp-export-buttons">
                <button id="irp-export-csv" class="button">Export to CSV</button>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Date</th>
                        <th>Responses</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                    <tr>
                        <td><?php echo esc_html($submission['email']); ?></td>
                        <td><?php echo date('M j, Y g:i a', strtotime($submission['date'])); ?></td>
                        <td>
                            <div class="irp-response-details">
                                <?php foreach ($submission['responses'] as $response): ?>
                                <div class="irp-response-row">
                                    <span class="irp-response-question"><?php echo esc_html($response->question_text); ?></span>
                                    <span class="irp-response-rating">Rating: <?php echo $response->rating_value; ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div id="add-question" class="irp-tab-content">
            <h2><?php echo isset($_GET['edit']) ? 'Edit Question' : 'Add New Question'; ?></h2>
            <form id="irp-question-form" method="post">
                <input type="hidden" name="id" id="irp-question-id" value="">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="irp-question-text">Question Text</label></th>
                        <td>
                            <textarea name="question_text" id="irp-question-text" rows="3" class="regular-text" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="irp-min-label">Minimum Label</label></th>
                        <td>
                            <input type="text" name="min_label" id="irp-min-label" class="regular-text" value="0 = does not apply" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="irp-max-label">Maximum Label</label></th>
                        <td>
                            <input type="text" name="max_label" id="irp-max-label" class="regular-text" value="10 = exactly applies" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="irp-min-value">Minimum Value</label></th>
                        <td>
                            <input type="number" name="min_value" id="irp-min-value" class="small-text" value="0" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="irp-max-value">Maximum Value</label></th>
                        <td>
                            <input type="number" name="max_value" id="irp-max-value" class="small-text" value="10" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="irp-display-order">Display Order</label></th>
                        <td>
                            <input type="number" name="display_order" id="irp-display-order" class="small-text" value="0" required>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Save Question</button>
                </p>
            </form>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Tab switching
        $('.irp-tab-button').on('click', function() {
            $('.irp-tab-button').removeClass('active');
            $(this).addClass('active');
            
            var tab = $(this).data('tab');
            $('.irp-tab-content').removeClass('active');
            $('#' + tab).addClass('active');
        });
        
        // Edit question
        $('.irp-edit-question').on('click', function() {
            var questionId = $(this).data('id');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'irp_get_question_data',
                    id: questionId,
                    nonce: '<?php echo wp_create_nonce('irp_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        $('#irp-question-id').val(response.data.id);
                        $('#irp-question-text').val(response.data.question_text);
                        $('#irp-min-label').val(response.data.min_label);
                        $('#irp-max-label').val(response.data.max_label);
                        $('#irp-min-value').val(response.data.min_value);
                        $('#irp-max-value').val(response.data.max_value);
                        $('#irp-display-order').val(response.data.display_order);
                        
                        $('.irp-tab-button[data-tab="add-question"]').click();
                        $('#add-question h2').text('Edit Question');
                    }
                }
            });
        });
        
        // Delete question
        $('.irp-delete-question').on('click', function() {
            var $button = $(this);
            var questionId = $button.data('id');
            
            if (!confirm('Are you sure you want to delete this question and all its responses? This action cannot be undone.')) {
                return;
            }
            
            $button.html('<span class="irp-spinner">⏳</span> Deleting...').prop('disabled', true);
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'irp_delete_question',
                    id: questionId,
                    nonce: '<?php echo wp_create_nonce('irp_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        $button.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            showAdminNotice('Question and its responses deleted successfully', 'success');
                        });
                    } else {
                        $button.html('Delete').prop('disabled', false);
                        showAdminNotice(response.data || 'Failed to delete question', 'error');
                    }
                },
                error: function(xhr) {
                    $button.html('Delete').prop('disabled', false);
                    showAdminNotice('Error: ' + xhr.responseText, 'error');
                }
            });
        });
        
        // Save question form
        $('#irp-question-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = $(this).serialize();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: formData + '&action=irp_save_question&nonce=<?php echo wp_create_nonce("irp_admin_nonce"); ?>',
                success: function(response) {
                    if (response.success) {
                        showAdminNotice('Question saved successfully', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAdminNotice('Failed to save question', 'error');
                    }
                }
            });
        });
        
        // Export to CSV
        $('#irp-export-csv').on('click', function() {
            window.location.href = ajaxurl + '?action=irp_export_csv&nonce=<?php echo wp_create_nonce("irp_admin_nonce"); ?>';
        });
        
        // Toggle response details
        $('.irp-response-details').on('click', function(e) {
            if ($(e.target).hasClass('irp-response-details')) {
                $(this).toggleClass('expanded');
            }
        });
        
        // Show admin notices
        function showAdminNotice(message, type) {
            var noticeClass = 'notice notice-' + type + ' is-dismissible';
            var noticeHTML = '<div class="' + noticeClass + '"><p>' + message + '</p></div>';
            
            $('.irp-admin-container').prepend(noticeHTML);
            setTimeout(function() {
                $('.notice').fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        }
    });
    </script>
    <?php
}

// AJAX handlers for admin
add_action('wp_ajax_irp_get_question_data', 'irp_get_question_data_callback');
add_action('wp_ajax_irp_save_question', 'irp_save_question_callback');
add_action('wp_ajax_irp_delete_question', 'irp_delete_question_callback');
add_action('wp_ajax_irp_export_csv', 'irp_export_csv_callback');

function irp_get_question_data_callback() {
    check_ajax_referer('irp_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission to edit questions');
    }

    global $wpdb;
    $db = new IRP_Database();
    $table_name = $wpdb->prefix . 'irp_questions';
    
    $question = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id = %d",
        intval($_POST['id'])
    ));
    
    if ($question) {
        wp_send_json_success($question);
    } else {
        wp_send_json_error('Question not found');
    }
}

function irp_save_question_callback() {
    check_ajax_referer('irp_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission to save questions');
    }

    $data = array(
        'question_text' => sanitize_text_field($_POST['question_text']),
        'min_label' => sanitize_text_field($_POST['min_label']),
        'max_label' => sanitize_text_field($_POST['max_label']),
        'min_value' => intval($_POST['min_value']),
        'max_value' => intval($_POST['max_value']),
        'display_order' => intval($_POST['display_order'])
    );
    
    if (isset($_POST['id']) && $_POST['id']) {
        $data['id'] = intval($_POST['id']);
    }
    
    $db = new IRP_Database();
    $result = $db->save_question($data);
    
    if ($result) {
        wp_send_json_success();
    } else {
        wp_send_json_error('Failed to save question');
    }
}

function irp_delete_question_callback() {
    check_ajax_referer('irp_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission to delete questions');
    }

    $question_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$question_id) {
        wp_send_json_error('Invalid question ID');
    }

    $db = new IRP_Database();
    $result = $db->delete_question($question_id);
    
    if ($result !== false) {
        wp_send_json_success();
    } else {
        global $wpdb;
        wp_send_json_error($wpdb->last_error ?: 'Failed to delete question and its responses');
    }
}

function irp_export_csv_callback() {
    check_ajax_referer('irp_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die('You do not have permission to export data');
    }

    global $wpdb;
    $db = new IRP_Database();
    $submissions = $db->get_grouped_submissions();
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=survey-submissions-' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    
    // Header row
    fputcsv($output, array('Email', 'Date', 'Session ID', 'Question', 'Rating'));
    
    // Data rows
    foreach ($submissions as $submission) {
        foreach ($submission['responses'] as $response) {
            fputcsv($output, array(
                $submission['email'],
                date('Y-m-d H:i:s', strtotime($submission['date'])),
                $submission['session_id'],
                $response->question_text,
                $response->rating_value
            ));
        }
    }
    
    fclose($output);
    exit;
}