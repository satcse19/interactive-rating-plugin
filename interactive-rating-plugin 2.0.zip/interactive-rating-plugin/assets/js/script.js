jQuery(document).ready(function($) {
    var sessionId = '';
    var currentQuestionIndex = 0;
    var totalQuestions = 0;
    var selectedRating = null;
    var userResponses = {};
    
    // Initialize the survey
    function initSurvey() {
        $('.irp-question-container').html('<div class="irp-loading">Loading survey...</div>');
        
        $.ajax({
            url: irp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'irp_get_question',
                nonce: irp_ajax.nonce
            },
            success: function(response) {
                if (response.status === 'success') {
                    sessionId = response.session_id;
                    currentQuestionIndex = response.question_index;
                    totalQuestions = response.total_questions;
                    
                    $('.irp-question-container').html(response.html);
                    addNavigationButtons();
                    setupQuestionEvents();
                    updateProgress();
                }
            }
        });
    }
    
    // Add navigation buttons dynamically
    function addNavigationButtons() {
        var buttonsHTML = `
            <div class="irp-button-container">
                ${currentQuestionIndex > 0 ? '<button class="irp-previous-button">Previous</button>' : ''}
                <button class="irp-next-button" disabled>Next</button>
                ${currentQuestionIndex < totalQuestions - 1 ? '<button class="irp-skip-button">Skip</button>' : ''}
            </div>
        `;
        $('.irp-question').append(buttonsHTML);
    }
    
    // Update progress indicator
    function updateProgress() {
        $('.irp-progress').remove();
        $('.irp-question h3').after(
            `<div class="irp-progress">Question ${currentQuestionIndex + 1} of ${totalQuestions}</div>`
        );
    }
    
    // Set up event handlers
    function setupQuestionEvents() {
        // Rating selection
        $('.irp-rating-option').on('click', function() {
            $('.irp-rating-option').removeClass('selected');
            $(this).addClass('selected');
            selectedRating = $(this).data('value');
            userResponses[currentQuestionIndex] = selectedRating;
            $('.irp-next-button').prop('disabled', false);
        });
        
        // Next button
        $('.irp-next-button').on('click', function() {
            $(this).html('<span class="irp-spinner">⏳</span> Processing...').prop('disabled', true);
            
            if (selectedRating !== null) {
                $.ajax({
                    url: irp_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'irp_save_response',
                        question_id: $('.irp-question').data('question-id'),
                        rating_value: selectedRating,
                        session_id: sessionId,
                        nonce: irp_ajax.nonce
                    },
                    success: function() {
                        loadNextQuestion();
                    },
                    error: function() {
                        $('.irp-next-button').html('Next').prop('disabled', false);
                    }
                });
            } else {
                loadNextQuestion();
            }
        });

        // Previous button
        $('.irp-previous-button').on('click', function() {
            $(this).html('<span class="irp-spinner">⏳</span> Loading...').prop('disabled', true);
            loadPreviousQuestion();
        });

        // Skip button
        $('.irp-skip-button').on('click', function() {
            $(this).html('<span class="irp-spinner">⏳</span> Processing...').prop('disabled', true);
            loadNextQuestion();
        });
    }
    
    // Load next question
    function loadNextQuestion() {
        currentQuestionIndex++;
        loadQuestion(currentQuestionIndex);
    }
    
    // Load previous question
    function loadPreviousQuestion() {
        currentQuestionIndex--;
        loadQuestion(currentQuestionIndex);
    }
    
    // Load specific question
    function loadQuestion(index) {
        $('.irp-question-container').html('<div class="irp-loading">Loading question...</div>');
        
        if (index >= totalQuestions) {
            showEmailForm();
            return;
        }
        
        $.ajax({
            url: irp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'irp_get_question',
                question_index: index,
                nonce: irp_ajax.nonce
            },
            success: function(response) {
                if (response.status === 'success') {
                    currentQuestionIndex = response.question_index;
                    $('.irp-question-container').html(response.html);
                    addNavigationButtons();
                    
                    // Restore previous selection if exists
                    if (userResponses[currentQuestionIndex] !== undefined) {
                        selectedRating = userResponses[currentQuestionIndex];
                        $(`.irp-rating-option[data-value="${selectedRating}"]`).addClass('selected');
                        $('.irp-next-button').prop('disabled', false);
                    } else {
                        selectedRating = null;
                        $('.irp-next-button').prop('disabled', true);
                    }
                    
                    setupQuestionEvents();
                    updateProgress();
                }
            },
            error: function() {
                $('.irp-previous-button, .irp-next-button, .irp-skip-button')
                    .html(function() {
                        return $(this).hasClass('irp-previous-button') ? 'Previous' : 
                               $(this).hasClass('irp-skip-button') ? 'Skip' : 'Next';
                    })
                    .prop('disabled', false);
            }
        });
    }
    
    // Show email form
    function showEmailForm() {
        $('.irp-question-container').hide();
        $('.irp-email-container').show();
        
        $('#irp-submit-email').on('click', function() {
            var email = $('#irp-user-email').val().trim();
            
            if (!isValidEmail(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            $(this).html('<span class="irp-spinner">⏳</span> Submitting...').prop('disabled', true);
            
            $.ajax({
                url: irp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'irp_save_email',
                    email: email,
                    session_id: sessionId,
                    nonce: irp_ajax.nonce
                },
                success: function() {
                    $('.irp-email-container').html(
                        '<div class="irp-thank-you">' +
                        '<h3>Thank you for completing our survey!</h3>' +
                        '<p>We appreciate your feedback.</p>' +
                        '</div>'
                    );
                },
                error: function() {
                    $('#irp-submit-email').html('Submit').prop('disabled', false);
                }
            });
        });
    }
    
    // Email validation
    function isValidEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Initialize
    initSurvey();
});