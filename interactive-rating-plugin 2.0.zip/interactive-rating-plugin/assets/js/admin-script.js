jQuery(document).ready(function($) {
    // Initialize admin interface
    initAdminInterface();

    function initAdminInterface() {
        setupQuestionManagement();
    }

    function setupQuestionManagement() {
        // Delete question button handler
        $(document).on('click', '.irp-delete-question', function() {
            const questionId = $(this).data('id');
            deleteQuestion(questionId);
        });
    }

    function deleteQuestion(questionId) {
        if (!confirm('Are you sure you want to permanently delete this question?')) {
            return;
        }

        const $deleteBtn = $(`.irp-delete-question[data-id="${questionId}"]`);
        const $row = $deleteBtn.closest('tr');
        
        // Show loading state
        $deleteBtn.html('<span class="irp-spinner">⏳</span> Deleting...').prop('disabled', true);

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'irp_delete_question',
                id: questionId,
                nonce: irp_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Remove row with animation
                    $row.fadeOut(300, function() {
                        $(this).remove();
                        showAdminNotice('Question deleted successfully', 'success');
                    });
                } else {
                    resetDeleteButton($deleteBtn);
                    showAdminNotice(response.data || 'Failed to delete question', 'error');
                }
            },
            error: function(xhr) {
                resetDeleteButton($deleteBtn);
                showAdminNotice('Error: ' + xhr.responseText, 'error');
            }
        });
    }

    function resetDeleteButton($button) {
        $button.html('Delete').prop('disabled', false);
    }

    function showAdminNotice(message, type) {
        const noticeClass = `notice notice-${type} is-dismissible`;
        const noticeHTML = `
            <div class="${noticeClass}">
                <p>${message}</p>
                <button type="button" class="notice-dismiss">
                    <span class="screen-reader-text">Dismiss this notice.</span>
                </button>
            </div>
        `;
        
        // Add notice and auto-remove after 5 seconds
        $('.wrap').prepend(noticeHTML);
        setTimeout(() => {
            $('.notice').fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
        
        // Manual dismiss
        $(document).on('click', '.notice-dismiss', function() {
            $(this).closest('.notice').remove();
        });
    }
});