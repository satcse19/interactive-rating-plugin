<?php
/*
Plugin Name: Interactive Rating Plugin
Description: A plugin for creating interactive rating surveys with email collection.
Version: 1.0
Author: Tushar
Website: devtushar.com
*/

if (!defined('ABSPATH')) exit;

define('IRP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IRP_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include necessary files
require_once IRP_PLUGIN_DIR . 'includes/class-database.php';
require_once IRP_PLUGIN_DIR . 'includes/shortcodes.php';
require_once IRP_PLUGIN_DIR . 'includes/admin/admin-dashboard.php';

class Interactive_Rating_Plugin {
    
    private $db;
    
    public function __construct() {
        $this->db = new IRP_Database();
        
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this->db, 'create_tables'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Initialize AJAX handlers
        $this->init_ajax_handlers();
    }
    
    public function enqueue_assets() {
        wp_enqueue_style('irp-frontend-style', IRP_PLUGIN_URL . 'assets/css/style.css');
        wp_enqueue_script('irp-frontend-script', IRP_PLUGIN_URL . 'assets/js/script.js', array('jquery'), '1.0', true);
        
        wp_localize_script('irp-frontend-script', 'irp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('irp_nonce')
        ));
    }
    
    public function enqueue_admin_assets($hook) {
        if ('toplevel_page_interactive-rating-plugin' !== $hook) {
            return;
        }
        
        wp_enqueue_style('irp-admin-style', IRP_PLUGIN_URL . 'assets/css/admin-style.css');
        wp_enqueue_script('irp-admin-script', IRP_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), '1.0', true);
        
        wp_localize_script('irp-admin-script', 'irp_admin', array(
            'nonce' => wp_create_nonce('irp_admin_nonce')
        ));
    }
    
    private function init_ajax_handlers() {
        // Frontend AJAX handlers
        add_action('wp_ajax_irp_get_question', 'irp_get_question_callback');
        add_action('wp_ajax_nopriv_irp_get_question', 'irp_get_question_callback');
        add_action('wp_ajax_irp_save_response', 'irp_save_response_callback');
        add_action('wp_ajax_nopriv_irp_save_response', 'irp_save_response_callback');
        add_action('wp_ajax_irp_save_email', 'irp_save_email_callback');
        add_action('wp_ajax_nopriv_irp_save_email', 'irp_save_email_callback');
        
        // Admin AJAX handlers
        add_action('wp_ajax_irp_get_question_data', 'irp_get_question_data_callback');
        add_action('wp_ajax_irp_save_question', 'irp_save_question_callback');
        add_action('wp_ajax_irp_delete_question', 'irp_delete_question_callback');
        add_action('wp_ajax_irp_export_csv', 'irp_export_csv_callback');
    }
    
    public function deactivate() {
        // Cleanup if needed
    }
}

new Interactive_Rating_Plugin();