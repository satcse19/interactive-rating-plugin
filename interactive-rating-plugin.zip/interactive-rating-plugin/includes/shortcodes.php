<?php
function irp_rating_survey_shortcode() {
    ob_start();
    ?>
    <div class="irp-survey-container">
        <div class="irp-question-container">
            <!-- Questions will be loaded here via AJAX -->
        </div>
        <div class="irp-email-container" style="display:none;">
            <h3>Thank you for completing our survey!</h3>
            <p>Please enter your email to receive the results:</p>
            <input type="email" id="irp-user-email" placeholder="your@email.com">
            <button id="irp-submit-email" class="irp-button">Submit</button>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Load first question
        loadQuestion(0);
        
        // Handle next button click
        $(document).on('click', '.irp-next-button', function() {
            var $question = $(this).closest('.irp-question');
            var questionId = $question.data('question-id');
            var questionIndex = $question.data('question-index');
            var ratingValue = $question.find('.irp-rating-option.active').data('value');
            var sessionId = '<?php echo isset($_COOKIE['irp_session_id']) ? $_COOKIE['irp_session_id'] : uniqid(); ?>';
            
            // Save response if rating was selected
            if (ratingValue !== undefined) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'irp_save_response',
                        nonce: '<?php echo wp_create_nonce('irp_nonce'); ?>',
                        question_id: questionId,
                        rating_value: ratingValue,
                        session_id: sessionId
                    },
                    success: function() {
                        loadQuestion(questionIndex + 1);
                    }
                });
            } else {
                // Just move to next question
                loadQuestion(questionIndex + 1);
            }
        });
        
        // Handle rating selection
        $(document).on('click', '.irp-rating-option', function() {
            $(this).addClass('active').siblings().removeClass('active');
            $(this).closest('.irp-question').find('.irp-next-button').prop('disabled', false);
        });
        
        // Handle skip button click
        $(document).on('click', '.irp-skip-button', function() {
            var questionIndex = $(this).closest('.irp-question').data('question-index');
            loadQuestion(questionIndex + 1);
        });
        
        // Handle email submission
        $(document).on('click', '#irp-submit-email', function() {
            var email = $('#irp-user-email').val();
            var sessionId = '<?php echo isset($_COOKIE['irp_session_id']) ? $_COOKIE['irp_session_id'] : ''; ?>';
            
            if (!isValidEmail(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'irp_save_email',
                    nonce: '<?php echo wp_create_nonce('irp_nonce'); ?>',
                    email: email,
                    session_id: sessionId
                },
                success: function(response) {
                    if (response.success) {
                        $('.irp-email-container').html('<p>Thank you! We will send the results to your email shortly.</p>');
                    } else {
                        alert('Failed to save email. Please try again.');
                    }
                }
            });
        });
        
        // Function to load question
        function loadQuestion(index) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'irp_get_question',
                    nonce: '<?php echo wp_create_nonce('irp_nonce'); ?>',
                    question_index: index
                },
                success: function(response) {
                    if (response.status === 'complete') {
                        $('.irp-question-container').hide();
                        $('.irp-email-container').show();
                    } else {
                        $('.irp-question-container').html(response.html);
                    }
                }
            });
        }
        
        // Email validation
        function isValidEmail(email) {
            var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            return regex.test(email);
        }
    });
    </script>
    
    <style>
    .irp-survey-container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background: #f9f9f9;
        border-radius: 8px;
    }
    .irp-question {
        margin-bottom: 20px;
    }
    .irp-rating-scale {
        display: flex;
        align-items: center;
        margin: 20px 0;
    }
    .irp-rating-options {
        display: flex;
        flex: 1;
        justify-content: space-between;
        margin: 0 10px;
    }
    .irp-rating-option {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: #ddd;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        position: relative;
    }
    .irp-rating-option.active {
        background: #4CAF50;
        color: white;
    }
    .irp-button {
        padding: 8px 16px;
        background: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .irp-button:disabled {
        background: #cccccc;
        cursor: not-allowed;
    }
    .irp-skip-button {
        padding: 8px 16px;
        background: #6c757d;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-left: 10px;
    }
    .irp-button-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    </style>
    <?php
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('interactive_rating_survey', 'irp_rating_survey_shortcode');

// AJAX handlers
add_action('wp_ajax_irp_get_question', 'irp_get_question_callback');
add_action('wp_ajax_nopriv_irp_get_question', 'irp_get_question_callback');
add_action('wp_ajax_irp_save_response', 'irp_save_response_callback');
add_action('wp_ajax_nopriv_irp_save_response', 'irp_save_response_callback');
add_action('wp_ajax_irp_save_email', 'irp_save_email_callback');
add_action('wp_ajax_nopriv_irp_save_email', 'irp_save_email_callback');

function irp_get_question_callback() {
    check_ajax_referer('irp_nonce', 'nonce');
    
    global $wpdb;
    $db = new IRP_Database();
    $questions = $db->get_questions();
    
    $session_id = isset($_COOKIE['irp_session_id']) ? $_COOKIE['irp_session_id'] : uniqid();
    setcookie('irp_session_id', $session_id, time() + 3600, '/');
    
    $question_index = isset($_POST['question_index']) ? intval($_POST['question_index']) : 0;
    
    if ($question_index >= count($questions)) {
        wp_send_json(array(
            'status' => 'complete',
            'message' => 'All questions completed'
        ));
    }
    
    $question = $questions[$question_index];
    
    ob_start();
    ?>
    <div class="irp-question" data-question-id="<?php echo $question->id; ?>" data-question-index="<?php echo $question_index; ?>">
        <h3><?php echo esc_html($question->question_text); ?></h3>
        <div class="irp-rating-scale">
            <span class="irp-min-label"><?php echo esc_html($question->min_label); ?></span>

            <div class="irp-rating-options">
                <?php for ($i = $question->min_value; $i <= $question->max_value; $i++): ?>
                  <div class="irp-rating-option" data-value="<?php echo $i; ?>">
                 <span class="irp-option-number"><?php echo $i; ?></span>
            <!-- Remove the tooltip div below to prevent duplicate numbers -->
                 </div>
            <?php endfor; ?>
            </div>

            </div>
            <span class="irp-max-label"><?php echo esc_html($question->max_label); ?></span>
        </div>
        <div class="irp-button-container">
            <button class="irp-next-button irp-button" disabled>Next</button>
            <button class="irp-skip-button">Skip</button>
        </div>
    </div>
    <?php
    $html = ob_get_clean();
    
    wp_send_json(array(
        'status' => 'success',
        'html' => $html,
        'question_index' => $question_index,
        'total_questions' => count($questions),
        'session_id' => $session_id
    ));
}

function irp_save_response_callback() {
    check_ajax_referer('irp_nonce', 'nonce');
    
    $question_id = isset($_POST['question_id']) ? intval($_POST['question_id']) : 0;
    $rating_value = isset($_POST['rating_value']) ? intval($_POST['rating_value']) : 0;
    $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
    
    if (!$question_id || !$session_id) {
        wp_send_json_error('Missing required data');
    }
    
    $db = new IRP_Database();
    $result = $db->save_response($question_id, $rating_value, $session_id);
    
    if ($result) {
        wp_send_json_success('Response saved');
    } else {
        wp_send_json_error('Failed to save response');
    }
}

function irp_save_email_callback() {
    check_ajax_referer('irp_nonce', 'nonce');
    
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
    
    if (!is_email($email) || !$session_id) {
        wp_send_json_error('Invalid email or session ID');
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'irp_responses';
    $result = $wpdb->query($wpdb->prepare(
        "UPDATE $table_name SET user_email = %s WHERE session_id = %s",
        $email, $session_id
    ));
    
    if ($result !== false) {
        wp_send_json_success('Email saved successfully');
    } else {
        wp_send_json_error('Failed to save email');
    }
}