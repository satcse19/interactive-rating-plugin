<?php
class IRP_Database {
    
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Questions table
        $table_name = $wpdb->prefix . 'irp_questions';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            question_text text NOT NULL,
            min_label varchar(100) DEFAULT '0 = does not apply',
            max_label varchar(100) DEFAULT '6 = exactly applies',
            min_value int NOT NULL DEFAULT 0,
            max_value int NOT NULL DEFAULT 10,
            display_order int NOT NULL DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Responses table
        $table_name_responses = $wpdb->prefix . 'irp_responses';
        $sql2 = "CREATE TABLE $table_name_responses (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            question_id mediumint(9) NOT NULL,
            rating_value int NOT NULL,
            session_id varchar(255) NOT NULL,
            user_email varchar(255) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            FOREIGN KEY (question_id) REFERENCES $table_name(id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        dbDelta($sql2);
        
        // Add indexes for better performance
        $wpdb->query("CREATE INDEX idx_session_id ON $table_name_responses (session_id)");
        $wpdb->query("CREATE INDEX idx_user_email ON $table_name_responses (user_email)");
        
        // Insert default question if none exist
        $existing_questions = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        if ($existing_questions == 0) {
            $wpdb->insert($table_name, array(
                'question_text' => 'I am lively and enthusiastic.',
                'min_label' => '0 = does not apply',
                'max_label' => '6 = exactly applies',
                'min_value' => 0,
                'max_value' => 6,
                'display_order' => 1
            ));
        }
    }
    
    public function get_questions() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'irp_questions';
        return $wpdb->get_results("SELECT * FROM $table_name ORDER BY display_order ASC");
    }
    
    public function save_response($question_id, $rating_value, $session_id, $email = null) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'irp_responses';
        
        $data = array(
            'question_id' => $question_id,
            'rating_value' => $rating_value,
            'session_id' => $session_id
        );
        
        if ($email) {
            $data['user_email'] = sanitize_email($email);
        }
        
        return $wpdb->insert($table_name, $data);
    }
    
    public function get_grouped_submissions() {
        global $wpdb;
        $responses_table = $wpdb->prefix . 'irp_responses';
        $questions_table = $wpdb->prefix . 'irp_questions';

        // Get all unique completed submissions (with email)
        $submissions = $wpdb->get_results("
            SELECT session_id, user_email, MAX(created_at) as completed_at
            FROM $responses_table
            WHERE user_email IS NOT NULL
            GROUP BY session_id, user_email
            ORDER BY completed_at DESC
        ");

        $grouped_data = array();

        foreach ($submissions as $submission) {
            // Get all responses for this submission
            $responses = $wpdb->get_results($wpdb->prepare("
                SELECT q.question_text, r.rating_value
                FROM $responses_table r
                LEFT JOIN $questions_table q ON r.question_id = q.id
                WHERE r.session_id = %s
                ORDER BY q.display_order ASC
            ", $submission->session_id));

            $grouped_data[] = array(
                'email' => $submission->user_email,
                'date' => $submission->completed_at,
                'session_id' => $submission->session_id,
                'responses' => $responses
            );
        }

        return $grouped_data;
    }
    
    public function save_question($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'irp_questions';
        
        if (isset($data['id']) && $data['id']) {
            // Update existing question
            return $wpdb->update($table_name, $data, array('id' => $data['id']));
        } else {
            // Insert new question
            return $wpdb->insert($table_name, $data);
        }
    }
    
    public function delete_question($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'irp_questions';
        return $wpdb->delete($table_name, array('id' => $id));
    }
}