/**
 * Interactive Rating Plugin - Admin JavaScript
 * Handles all admin-side functionality including:
 * - Tab navigation
 * - Question management (add/edit/delete)
 * - Data export
 */

jQuery(document).ready(function($) {
    // Initialize admin interface
    initAdminInterface();

    /**
     * Initialize all admin interface functionality
     */
    function initAdminInterface() {
        setupTabNavigation();
        setupQuestionManagement();
        setupDataExport();
        setupFormValidation();
    }

    /**
     * Set up tab navigation functionality
     */
    function setupTabNavigation() {
        $('.irp-tab-button').on('click', function(e) {
            e.preventDefault();
            
            // Get the target tab from data attribute
            const targetTab = $(this).data('tab');
            
            // Update active tab button
            $('.irp-tab-button').removeClass('active');
            $(this).addClass('active');
            
            // Update active tab content
            $('.irp-tab-content').removeClass('active');
            $(`#${targetTab}`).addClass('active');
            
            // Clear form if switching away from add/edit tab
            if (targetTab !== 'add-question') {
                resetQuestionForm();
            }
        });
    }

    /**
     * Set up question management functionality (CRUD operations)
     */
    function setupQuestionManagement() {
        // Edit question button handler
        $(document).on('click', '.irp-edit-question', function() {
            const questionId = $(this).data('id');
            loadQuestionData(questionId);
        });

        // Delete question button handler
        $(document).on('click', '.irp-delete-question', function() {
            const questionId = $(this).data('id');
            deleteQuestion(questionId);
        });

        // Question form submission handler
        $('#irp-question-form').on('submit', function(e) {
            e.preventDefault();
            saveQuestion();
        });
    }

    /**
     * Load question data for editing
     * @param {number} questionId - The ID of the question to edit
     */
    function loadQuestionData(questionId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'irp_get_question_data',
                id: questionId,
                nonce: irp_admin.nonce
            },
            beforeSend: function() {
                // Show loading indicator
                $('#add-question').append('<div class="irp-loading">Loading...</div>');
            },
            success: function(response) {
                if (response.success) {
                    // Populate form fields
                    $('#irp-question-id').val(response.data.id);
                    $('#irp-question-text').val(response.data.question_text);
                    $('#irp-min-label').val(response.data.min_label);
                    $('#irp-max-label').val(response.data.max_label);
                    $('#irp-min-value').val(response.data.min_value);
                    $('#irp-max-value').val(response.data.max_value);
                    $('#irp-display-order').val(response.data.display_order);

                    // Switch to edit tab and update header
                    $('.irp-tab-button[data-tab="add-question"]').click();
                    $('#add-question h2').text('Edit Question');
                } else {
                    alert('Failed to load question data');
                }
            },
            complete: function() {
                $('.irp-loading').remove();
            },
            error: function() {
                alert('Error loading question data');
            }
        });
    }

    /**
     * Save question (both new and existing)
     */
    function saveQuestion() {
        const formData = $('#irp-question-form').serializeArray();
        const formattedData = {};

        // Convert form data to object
        $.each(formData, function(i, field) {
            formattedData[field.name] = field.value;
        });

        // Add action and nonce
        formattedData.action = 'irp_save_question';
        formattedData.nonce = irp_admin.nonce;

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formattedData,
            beforeSend: function() {
                $('.submit .button').prop('disabled', true).text('Saving...');
            },
            success: function(response) {
                if (response.success) {
                    alert('Question saved successfully');
                    window.location.reload();
                } else {
                    alert('Failed to save question');
                }
            },
            error: function() {
                alert('Error saving question');
            },
            complete: function() {
                $('.submit .button').prop('disabled', false).text('Save Question');
            }
        });
    }

    /**
     * Delete a question after confirmation
     * @param {number} questionId - The ID of the question to delete
     */
    function deleteQuestion(questionId) {
        if (!confirm('Are you sure you want to delete this question? This action cannot be undone.')) {
            return;
        }

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'irp_delete_question',
                id: questionId,
                nonce: irp_admin.nonce
            },
            beforeSend: function() {
                $(`.irp-delete-question[data-id="${questionId}"]`).prop('disabled', true).text('Deleting...');
            },
            success: function(response) {
                if (response.success) {
                    alert('Question deleted successfully');
                    window.location.reload();
                } else {
                    alert('Failed to delete question');
                }
            },
            error: function() {
                alert('Error deleting question');
            }
        });
    }

    /**
     * Set up data export functionality
     */
    function setupDataExport() {
        $('#irp-export-csv').on('click', function(e) {
            e.preventDefault();
            exportToCSV();
        });
    }

    /**
     * Export response data to CSV
     */
    function exportToCSV() {
        // Open export URL in new tab
        window.open(
            ajaxurl + '?action=irp_export_csv&nonce=' + irp_admin.nonce,
            '_blank'
        );
    }

    /**
     * Set up form validation
     */
    function setupFormValidation() {
        $('#irp-question-form').validate({
            rules: {
                question_text: 'required',
                min_label: 'required',
                max_label: 'required',
                min_value: {
                    required: true,
                    number: true
                },
                max_value: {
                    required: true,
                    number: true,
                    greaterThanMin: true
                },
                display_order: {
                    required: true,
                    number: true
                }
            },
            messages: {
                max_value: {
                    greaterThanMin: 'Max value must be greater than min value'
                }
            },
            errorClass: 'irp-form-error',
            errorElement: 'span',
            highlight: function(element, errorClass) {
                $(element).addClass('irp-input-error');
            },
            unhighlight: function(element, errorClass) {
                $(element).removeClass('irp-input-error');
            }
        });

        // Custom validation method for max > min
        $.validator.addMethod('greaterThanMin', function(value, element) {
            const minValue = parseFloat($('#irp-min-value').val());
            const maxValue = parseFloat(value);
            return maxValue > minValue;
        }, 'Max value must be greater than min value');
    }

    /**
     * Reset the question form to default state
     */
    function resetQuestionForm() {
        $('#irp-question-form')[0].reset();
        $('#irp-question-id').val('');
        $('#add-question h2').text('Add New Question');
        $('.irp-input-error').removeClass('irp-input-error');
        $('.irp-form-error').remove();
    }
});