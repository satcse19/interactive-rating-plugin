jQuery(document).ready(function($) {
    var sessionId = '';
    var currentQuestionIndex = 0;
    var totalQuestions = 0;
    var selectedRating = null;
    
    // Initialize the survey
    function initSurvey() {
        $('.irp-question-container').html('<div class="irp-loading">Loading survey...</div>');
        
        $.ajax({
            url: irp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'irp_get_question',
                nonce: irp_ajax.nonce
            },
            success: function(response) {
                if (response.status === 'success') {
                    sessionId = response.session_id;
                    currentQuestionIndex = response.question_index;
                    totalQuestions = response.total_questions;
                    
                    $('.irp-question-container').html(response.html);
                    setupQuestionEvents();
                    updateProgress();
                }
            }
        });
    }
    
    // Update progress indicator
    function updateProgress() {
        $('.irp-progress').remove();
        $('.irp-question h3').after(
            `<div class="irp-progress">Question ${currentQuestionIndex + 1} of ${totalQuestions}</div>`
        );
    }
    
    // Set up event handlers for the current question
    function setupQuestionEvents() {
        $('.irp-rating-option').on('click', function() {
            $('.irp-rating-option').removeClass('selected');
            $(this).addClass('selected');
            selectedRating = $(this).data('value');
            $('.irp-next-button').prop('disabled', false);
        });
        
        $('.irp-next-button').on('click', function() {
            // Show loading state
            $(this).html('<span class="irp-spinner">⏳</span> Processing...').prop('disabled', true);
            
            // Save the response if rating was selected
            if (selectedRating !== null) {
                $.ajax({
                    url: irp_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'irp_save_response',
                        question_id: $('.irp-question').data('question-id'),
                        rating_value: selectedRating,
                        session_id: sessionId,
                        nonce: irp_ajax.nonce
                    },
                    success: function() {
                        loadNextQuestion();
                    },
                    error: function() {
                        $('.irp-next-button').html('Next').prop('disabled', false);
                    }
                });
            } else {
                // Just move to next question without saving
                loadNextQuestion();
            }
        });

        // Skip question button handler
        $('.irp-skip-button').on('click', function() {
            loadNextQuestion();
        });
    }
    
    // Load next question or show email form
    function loadNextQuestion() {
        currentQuestionIndex++;
        
        if (currentQuestionIndex < totalQuestions) {
            loadQuestion(currentQuestionIndex);
        } else {
            showEmailForm();
        }
    }
    
    // Load a specific question
    function loadQuestion(index) {
        $('.irp-question-container').html('<div class="irp-loading">Loading next question...</div>');
        selectedRating = null;
        
        $.ajax({
            url: irp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'irp_get_question',
                question_index: index,
                nonce: irp_ajax.nonce
            },
            success: function(response) {
                if (response.status === 'success') {
                    currentQuestionIndex = response.question_index;
                    $('.irp-question-container').html(response.html);
                    setupQuestionEvents();
                    updateProgress();
                } else if (response.status === 'complete') {
                    showEmailForm();
                }
            }
        });
    }
    
    // Show the email collection form
    function showEmailForm() {
        $('.irp-question-container').hide();
        $('.irp-email-container').show();
        
        $('#irp-submit-email').on('click', function() {
            var email = $('#irp-user-email').val().trim();
            
            if (!isValidEmail(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            $(this).html('<span class="irp-spinner">⏳</span> Submitting...').prop('disabled', true);
            
            $.ajax({
                url: irp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'irp_save_email',
                    email: email,
                    session_id: sessionId,
                    nonce: irp_ajax.nonce
                },
                success: function() {
                    $('.irp-email-container').html(
                        '<div class="irp-thank-you">' +
                        '<h3>Thank you for completing our survey!</h3>' +
                        '<p>We appreciate your feedback.</p>' +
                        '</div>'
                    );
                },
                error: function() {
                    $('#irp-submit-email').html('Submit').prop('disabled', false);
                }
            });
        });
    }
    
    // Simple email validation
    function isValidEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Initialize the survey when the page loads
    initSurvey();
});